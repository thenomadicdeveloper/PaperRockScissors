//
//  ContentView.swift
//  PRS
//
//  Created by Davin Henrik on 1/13/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
