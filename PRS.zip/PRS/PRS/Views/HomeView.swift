//
//  HomeView.swift
//  PRS
//
//  Created by Davin Henrik on 1/13/23.
//

import SwiftUI

struct HomeView: View {
    @State private var choice: String = ""
    @State var play: Bool = false
    @State var compChoice: String = ""
    @State var decision: String = ""
    let choices = ["Paper", "Rock", "Scissors"]
    let compChoices = ["Paper", "Rock", "Scissors"]
    var body: some View {
        VStack {
            Text("\(decision)")
                .font(.largeTitle)
                .foregroundColor(self.decision == "Winner!" ? .green : self.decision == "Tie" ? .black : .red)
                .padding()
            Divider()
            Text("Computer's Choice:")
                .padding()
            Text("\(compChoice)")
            Divider()
            VStack {
                Picker("Make a selection", selection: $choice) {
                    ForEach(choices, id: \.self) {
                        Text($0)
                    }
                }
            }.pickerStyle(.segmented)
            Divider()
            VStack {
                Text("Your Selected Choice:")
                    .padding()
                Text("\(choice)")
                    .font(.title2)
                    .foregroundColor(.blue)
                    .padding()
            }
            Divider()
            Button("Play", action: {
                play.toggle()
                compChoice = compChoices.randomElement()!
                winner(userAnswer: choice, compAnswer: compChoice)
            })
            .buttonStyle(.bordered)
            .disabled ({
                if choice.count < 4 {
                    return true }
                else {
                    return false
                }
            }())
        }
    }
    func winner(userAnswer: String, compAnswer: String) {
        if userAnswer == compAnswer {
            decision = "Tie"
        } else if userAnswer == "Rock" && compAnswer == "Paper" {
            decision = "Loser!"
        } else if userAnswer == "Rock" && compAnswer == "Scissors" {
            decision = "Winner!"
        } else if userAnswer == "Paper" && compAnswer == "Rock" {
            decision = "Winner!"
        } else if userAnswer == "Paper" && compAnswer == "Scissors" {
            decision = "Loser!"
        } else if  userAnswer == "Scissors" && compAnswer == "Rock" {
            decision = "Loser!"
        } else if userAnswer == "Scissors" && compAnswer == "Paper" {
            decision = "Loser!"
        }
    }
}


struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
