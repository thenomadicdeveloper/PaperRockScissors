//
//  PRSModel.swift
//  PRS
//
//  Created by Davin Henrik on 1/13/23.
//

import Foundation

struct PRSModel {
    
}
