//
//  PRSApp.swift
//  PRS
//
//  Created by Davin Henrik on 1/13/23.
//

import SwiftUI

@main
struct PRSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
